#!/usr/bin/env node

/**
 * Migração segura: Dados para serem migrados.xlsx -> facilities_answers
 *
 * Uso:
 *   node scripts/migrate-appsheet.js --dry-run
 *   node scripts/migrate-appsheet.js --execute
 *   node scripts/migrate-appsheet.js --execute --overwrite
 *
 * Requer:
 *   npm install xlsx
 *
 * O script NÃO cria famílias nem perguntas.
 * Ele usa as famílias e perguntas já existentes no banco atual.
 */

const path = require("node:path");
const fs = require("node:fs");
const XLSX = require("xlsx");
const prisma = require("../Utils/prisma");

const args = new Set(process.argv.slice(2));
const EXECUTE = args.has("--execute");
const OVERWRITE = args.has("--overwrite");
const DRY_RUN = !EXECUTE;

const workbookPath = path.resolve(
  process.env.APPSHEET_XLSX ||
  path.join(__dirname, "../../Dados para serem migrados.xlsx")
);

const reportPath = path.resolve(
  process.env.MIGRATION_REPORT || "migration-appsheet-report.json"
);

const facilitiesMap = {
  "Numeração do levantamento:": "num_levantamento",
  "Nome do Morador:": "nome_morador",
  "Localização:": "localizacao",
  "Endereço:": "endereco",
  "Telefone:": "telefone_contato",
  "Dono do Telefone:": "dono_telefone",
  "Qual a Renda mensal familiar?": "renda_mensal_total",
  "Qual o modelo de chefia da família?": "chefe_familia",
  "Quantidade de crianças na 1º infância(1 a 5 anos)": "criancas_1_a_5",
  "Quantidade de crianças (6 a 9 anos)": "criancas_6_a_9",
  "Quantidade de pré-adolescentes (10 a 14 anos)": "pre_adolescentes_10_a_14",
  "Quantidade de Adolescentes (15 a 19 anos)": "adolescentes_15_a_19",
  "Relação de parentesco na casa:": "parentesco_casa",
  "Relação de parentesco no lote:": "parentesco_lote",
  "Saberes adquiridos:": "saberes_adquiridos",
  "Idade do morador:": "idade",
  "Quantidade de moradores no lote:": "num_moradores",
  "Quantidade de casas no lote:": "casas_no_lote",
  "Quantidade de famílias no lote:": "familias_no_lote",
  "Ocupação do responsável 1:": "ocupacao_responsavel_1",
  "Ocupação do responsável 2:": "ocupacao_responsavel_2",
  "Ocupação do respondente não responsável:": "ocupacao_respondente_nao_responsavel",
  "Escolaridade:": "escolaridade",
  "Se for estudante, onde estuda?": "onde_estuda",
  "Empregabilidade do responsável 1:": "empregabilidade_responsavel_1",
  "Empregabilidade do responsável 2:": "empregabilidade_responsavel_2",
  "A família se autodeclara:": "auto_declaracao",
  "A família se considera quilombola?": "considera_quilombola",
  "Pratica de artesanato:": "pratica_artesanato",
  "Comorbidades na família (membro 1):": "comorbidades_membro_1",
  "Comorbidades na família (membro 2):": "comorbidades_membro_2",
  "Comorbidades na família (membro 3):": "comorbidades_membro_3",
  "Comorbidades na família (membro 4):": "comorbidades_membro_4",
  "Pessoas com deficiência na família (membro 1):": "deficiencia_membro_1",
  "Pessoas com deficiência na família (membro 2):": "deficiencia_membro_2",
  "Pessoas com deficiência na família (membro 3):": "deficiencia_membro_3",
  "Pessoas com deficiência na família (membro 4):": "deficiencia_membro_4",
  "Medicamento de uso contínuo:": "medicamento_uso_continuo",
  "Finalidade do medicamento:": "finalidade_medicamento",
  "Pessoas com deficiência respiratória crônica (membro 1):": "doenca_respiratoria_membro_1",
  "Pessoas com deficiência respiratória crônica (membro 2):": "doenca_respiratoria_membro_2",
  "Pessoas com deficiência respiratória crônica (membro 3):": "doenca_respiratoria_membro_3",
  "Sabem dizer em que ano a casa foi construída? ": "ano_construcao_casa",
  " Há quanto tempo residem neste imóvel?": "tempo_residencia_imovel",
  "Quem executou a casa?": "quem_executou_casa",
  "Quantas gerações moram na casa:": "geracoes_na_casa",
  "Quantas gerações moram no lote:": "geracoes_no_lote",
  "Origem - cidade e bairro de origem:": "origem_cidade_bairro",
  "Em caso de moradia em outro bairro cidade,  informe aqui:": "outros_bairros_cidade_detalhes",
  "Há quantos anos a família reside em Araçatiba:": "anos_residencia_aracatiba",
  "A família possui algum outro imóvel ou terreno?": "possui_outro_imovel",
  "O aluguel é em relação a renda familiar mensal:": "relacao_aluguel_renda",
  "O imóvel já recebeu algum tipo de reforma ou ampliação:": "imovel_teve_reforma",
  "Que tipo de reforma foi executada": "tipo_reforma_executada",
  "Quem executou a reforma:": "quem_executou_reforma",
  "Quem custeou a reforma:": "quem_custeou_reforma",
  "Boa convivência com a vizinhança?": "boa_vivencia_vizinhos",
  "Formas de uso do quintal:": "formas_uso_quintal",
  "Hábitos alimentares:": "habitos_alimentares",
  "Representação na comunidade:": "representacao_comunidade",
  "Profissionais e lojas indicadas pela família:": "indicacao_profissionais",
  "Estão recebendo boleto de cobrança (talão) de água e energia?": "recebe_boleto_agua_energia",
  "Observações": "observacoes"
};

const estruturalMap = {
  "__FAMILY_ID__": "EST011",
  "Nome do Morador:": "EST012",
  "Há problemas de insalubridade com:": "EST013",
  "Existe a necessidade de realização de reparos estruturais?": "EST014",
  "Existe a possibilidade de resolver os problemas dentro do próprio terreno (a partir da\nestrutura existente)?": "EST016",
  "De acordo com a documentação da Defesa Civil, a edificação encontra-se em área de risco?": "EST017",
  "Número de quartos:": "EST018",
  "Superpopulação:": "EST019",
  "Coabitação:": "EST020",
  "Inserção no lote:": "EST021",
  "Fundações:": "EST022",
  "Estrutura:": "EST023",
  "Paredes:": "EST024",
  "Cobertura:": "EST025",
  "Esquadrias:": "EST026",
  "Hidrossanitário:": "EST027",
  "Elétrico:": "EST028",
  "Banheiro(s):": "EST029",
  "Cozinha/área de serviço:": "EST030",
  "Conforto:": "EST031",
  "Avaliação da residência:": "EST032",
  "A circulação interna na unidade é segura e adequada para todos os membros da família?": "EST033",
  "Como você avaliaria a infraestrutura urbana no entorno da residência?": "EST034",
  "Como você avaliaria a acessibilidade, transporte, lazer, saneamento básico e serviços?": "EST035",
  "Na sua opinião, qual a situação geral da casa?": "EST036",
  "Diagnóstico preliminar:": "EST037",
  "Aponte pelo menos uma situação positiva da edificação que você observou.": "EST038",
  "Observações gerais:": "EST039",
  "Possui reservatório de água na residência?": "EST001",
  "A unidade tem banheiro?": "EST002",
  "A unidade tem cozinha?": "EST003",
  "Data da visita:": "EST004",
  "Nome do responsável pelo formulário:": "EST005",
  "Nome do responsável pelo relatório fotográfico:": "EST006",
  "Nome do responsável pelo levantamento arquitetônico:": "EST007",
  "Nome do agente comunitário:": "EST008",
  "Outros profissionais envolvidos (nomes e funções desempenhadas):": "EST009",
  "Demanda apresentada pela família:": "EST010"
};

function norm(v) {
  return String(v ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function digits(v) {
  return String(v ?? "").replace(/\D/g, "");
}

function empty(v) {
  return v === undefined || v === null || String(v).trim() === "";
}

function sourceValue(v) {
  if (empty(v)) return null;
  if (v instanceof Date) return v;
  return v;
}

function splitMulti(v) {
  if (Array.isArray(v)) return v;
  const raw = String(v).trim();
  if (!raw) return null;

  // AppSheet usa " , " entre escolhas. Mantém vírgulas internas de opções.
  const parts = raw.split(/\s,\s/).map(x => x.trim()).filter(Boolean);
  return parts.length ? parts : [raw];
}

function serialize(value, type, code) {
  if (empty(value)) return null;

  if (code === "imovel_teve_reforma") {
    if (value === true || String(value).toLowerCase() === "true") return "Sim";
    if (value === false || String(value).toLowerCase() === "false") return "Não";
  }

  if (type === "resposta_multipla") {
    return JSON.stringify(splitMulti(value));
  }

  if (typeof value === "number") {
    return Number.isInteger(value) ? String(value) : String(value);
  }

  return String(value).trim();
}

function getFamilySourceId(row) {
  return String(row["ID"] ?? "").trim();
}

function getStructuralFamilySourceId(row) {
  return String(row["Nome do Morador:"] ?? "").trim() || null;
}

async function loadFamilyMatches(facilitiesRows) {
  const families = await prisma.family.findMany({
    include: {
      dadosPessoais: true,
      memberships: {
        include: { user: true }
      }
    }
  });

  const byName = new Map();
  const byPhone = new Map();

  for (const family of families) {
    const name = norm(family.dadosPessoais?.nomeMorador);
    const phone = digits(family.dadosPessoais?.telefone);

    if (name) {
      if (!byName.has(name)) byName.set(name, []);
      byName.get(name).push(family);
    }
    if (phone) {
      if (!byPhone.has(phone)) byPhone.set(phone, []);
      byPhone.get(phone).push(family);
    }
  }

  const result = new Map();
  const issues = [];

  for (const row of facilitiesRows) {
    const sourceId = getFamilySourceId(row);
    const name = norm(row["Nome do Morador:"]);
    const phone = digits(row["Telefone:"]);

    let candidates = name ? (byName.get(name) || []) : [];

    if (candidates.length === 0 && phone) {
      candidates = byPhone.get(phone) || [];
    }

    if (candidates.length !== 1) {
      issues.push({
        type: candidates.length === 0 ? "family_not_found" : "family_ambiguous",
        sourceFamilyId: sourceId,
        name: row["Nome do Morador:"],
        candidates: candidates.map(f => ({
          id: f.id,
          name: f.dadosPessoais?.nomeMorador
        }))
      });
      continue;
    }

    result.set(sourceId, candidates[0]);
  }

  return { result, issues };
}

function chooseUser(family, responsibleName = null) {
  if (responsibleName) {
    const direct = family.memberships
      .map(m => m.user)
      .filter(Boolean)
      .filter(u => norm(u.nome) === norm(responsibleName));

    if (direct.length === 1) return direct[0].id;
  }

  const interviewers = family.memberships
    .map(m => m.user)
    .filter(Boolean)
    .filter(u => u.tipoUsuario === "Entrevistador");

  return interviewers.length === 1 ? interviewers[0].id : null;
}

async function main() {
  if (!fs.existsSync(workbookPath)) {
    throw new Error(`Arquivo XLSX não encontrado: ${workbookPath}`);
  }

  const wb = XLSX.readFile(workbookPath, { cellDates: true });
  const facilities = XLSX.utils.sheet_to_json(wb.Sheets["Facilities"], { defval: null });
  const structural = XLSX.utils.sheet_to_json(wb.Sheets["Edificação"], { defval: null });

  const codes = [
    ...Object.values(facilitiesMap),
    ...Object.values(estruturalMap)
  ].filter(Boolean);

  const questions = await prisma.facilitiesQuestion.findMany({
    where: { codigo: { in: [...new Set(codes)] } }
  });

  const questionByCode = new Map(questions.map(q => [q.codigo, q]));
  const report = {
    mode: DRY_RUN ? "dry-run" : "execute",
    overwrite: OVERWRITE,
    workbook: workbookPath,
    summary: {},
    issues: [],
    skippedColumns: [],
    existingAnswers: 0,
    toCreate: 0,
    toUpdate: 0,
    rowsProcessed: 0
  };

  for (const code of new Set(codes)) {
    const q = questionByCode.get(code);
    if (!q) report.issues.push({ type: "question_not_found", code });
    else if (!q.ativa) report.issues.push({ type: "question_inactive", code, texto: q.texto });
  }

  const { result: familyMatches, issues: familyIssues } =
    await loadFamilyMatches(facilities);
  report.issues.push(...familyIssues);

  const sourceUsed = new Set([
    "ID",
    ...Object.keys(facilitiesMap),
    "ID_edificação:"
  ]);

  for (const row of facilities) {
    const sourceFamilyId = getFamilySourceId(row);
    const family = familyMatches.get(sourceFamilyId);
    if (!family) continue;

    for (const [column, code] of Object.entries(facilitiesMap)) {
      const value = sourceValue(row[column]);
      if (empty(value)) continue;

      const q = questionByCode.get(code);
      if (!q || !q.ativa) continue;

      const resposta = serialize(value, q.tipo, code);
      if (resposta === null) continue;

      report.rowsProcessed++;

      const existing = await prisma.facilitiesAnswer.findUnique({
        where: {
          familyId_perguntaId: {
            familyId: family.id,
            perguntaId: q.id
          }
        }
      });

      if (existing) {
        report.existingAnswers++;
        if (OVERWRITE) report.toUpdate++;
      } else {
        report.toCreate++;
      }

      if (EXECUTE && (!existing || OVERWRITE)) {
        // A gravação efetiva é feita mais abaixo em uma transação.
      }
    }
  }

  for (const row of structural) {
    const familySourceId = String(row["Nome do Morador:"] ?? "").trim();
    if (!familySourceId) {
      report.issues.push({
        type: "structural_without_family",
        structuralId: row["ID_edificação:"]
      });
      continue;
    }

    const family = familyMatches.get(familySourceId);
    if (!family) {
      report.issues.push({
        type: "structural_family_not_found",
        structuralId: row["ID_edificação:"],
        sourceFamilyId: familySourceId
      });
      continue;
    }

    const responsible = row["Nome do responsável pelo formulário:"];

    for (const [column, code] of Object.entries(estruturalMap)) {
      let value;

      if (column === "__FAMILY_ID__") {
        value = familySourceId;
      } else {
        value = sourceValue(row[column]);
      }

      if (empty(value)) continue;

      const q = questionByCode.get(code);
      if (!q || !q.ativa) continue;

      const resposta = serialize(value, q.tipo, code);
      if (resposta === null) continue;

      report.rowsProcessed++;

      const existing = await prisma.facilitiesAnswer.findUnique({
        where: {
          familyId_perguntaId: {
            familyId: family.id,
            perguntaId: q.id
          }
        }
      });

      if (existing) {
        report.existingAnswers++;
        if (OVERWRITE) report.toUpdate++;
      } else {
        report.toCreate++;
      }
    }

    if (responsible && !family.memberships.some(
      m => m.user && norm(m.user.nome) === norm(responsible)
    )) {
      report.issues.push({
        type: "structural_responsible_not_found",
        sourceFamilyId: familySourceId,
        responsible
      });
    }
  }

  report.summary = {
    facilitiesRows: facilities.length,
    structuralRows: structural.length,
    structuralRowsWithFamilyId: structural.filter(r => !empty(r["Nome do Morador:"])).length,
    familiesMatched: familyMatches.size,
    answersToCreate: report.toCreate,
    answersToUpdate: report.toUpdate,
    answersAlreadyExisting: report.existingAnswers,
    issues: report.issues.length
  };

  if (EXECUTE && report.issues.some(i =>
    ["question_not_found", "question_inactive", "family_not_found", "family_ambiguous"]
      .includes(i.type)
  )) {
    throw new Error(
      "Migração abortada: existem problemas estruturais no relatório. Execute o dry-run e corrija-os antes."
    );
  }

  if (EXECUTE) {
    await prisma.$transaction(async tx => {
      const familyRows = facilities;

      for (const row of familyRows) {
        const family = familyMatches.get(getFamilySourceId(row));
        if (!family) continue;

        for (const [column, code] of Object.entries(facilitiesMap)) {
          const value = sourceValue(row[column]);
          if (empty(value)) continue;

          const q = questionByCode.get(code);
          if (!q || !q.ativa) continue;

          const resposta = serialize(value, q.tipo, code);
          if (resposta === null) continue;

          const existing = await tx.facilitiesAnswer.findUnique({
            where: {
              familyId_perguntaId: {
                familyId: family.id,
                perguntaId: q.id
              }
            }
          });

          if (existing && !OVERWRITE) continue;

          await tx.facilitiesAnswer.upsert({
            where: {
              familyId_perguntaId: {
                familyId: family.id,
                perguntaId: q.id
              }
            },
            update: {
              resposta,
              userId: existing?.userId ?? null
            },
            create: {
              familyId: family.id,
              perguntaId: q.id,
              resposta,
              dataResposta: row["Data da 1ª visita:"] instanceof Date
                ? row["Data da 1ª visita:"]
                : undefined,
              userId: null
            }
          });
        }
      }

      for (const row of structural) {
        const familySourceId = String(row["Nome do Morador:"] ?? "").trim();
        const family = familyMatches.get(familySourceId);
        if (!family) continue;

        const responsible = row["Nome do responsável pelo formulário:"];
        const userId = chooseUser(family, responsible);

        for (const [column, code] of Object.entries(estruturalMap)) {
          const value = column === "__FAMILY_ID__"
            ? familySourceId
            : sourceValue(row[column]);

          if (empty(value)) continue;

          const q = questionByCode.get(code);
          if (!q || !q.ativa) continue;

          const resposta = serialize(value, q.tipo, code);
          if (resposta === null) continue;

          const existing = await tx.facilitiesAnswer.findUnique({
            where: {
              familyId_perguntaId: {
                familyId: family.id,
                perguntaId: q.id
              }
            }
          });

          if (existing && !OVERWRITE) continue;

          await tx.facilitiesAnswer.upsert({
            where: {
              familyId_perguntaId: {
                familyId: family.id,
                perguntaId: q.id
              }
            },
            update: {
              resposta,
              userId: userId ?? existing?.userId ?? null
            },
            create: {
              familyId: family.id,
              perguntaId: q.id,
              resposta,
              dataResposta: row["Data da visita:"] instanceof Date
                ? row["Data da visita:"]
                : undefined,
              userId
            }
          });
        }
      }
    });
  }

  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), "utf8");

  console.log(JSON.stringify(report.summary, null, 2));
  console.log(`Relatório: ${reportPath}`);

  if (DRY_RUN) {
    console.log("\nDRY-RUN: nenhuma alteração foi feita no banco.");
    console.log("Quando o relatório estiver aprovado, execute com --execute.");
  }
}

main()
  .catch(err => {
    console.error("\nMIGRATION ERROR:", err.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
